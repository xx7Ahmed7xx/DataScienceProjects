guides and references:
https://github.com/hwangmpaula/FBI-gun-data-analysis
https://github.com/shilin-li/Investigate_the_FBI_Gun_Dataset