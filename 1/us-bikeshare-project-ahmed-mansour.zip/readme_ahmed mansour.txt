I have taken a look from this github repo to have an idea of what output to follow:
https://github.com/YashMotwani/US-Bikeshare-Data-Exploration-Program/blob/master/bikeshare_2.py